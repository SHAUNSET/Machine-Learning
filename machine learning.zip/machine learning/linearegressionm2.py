import math
import numpy as np
import matplotlib.pyplot as plt

# -------- Sample Data --------
x_train = np.array([1.0, 2.0])     # House sizes in 1000 sqft
y_train = np.array([300.0, 500.0]) # Prices in 1000s of dollars

# -------- Cost Function --------
def compute_cost(x, y, w, b):
    m = x.shape[0] 
    cost = 0
    for i in range(m):
        f_wb = w * x[i] + b
        cost += (f_wb - y[i])**2
    return cost / (2 * m)

# -------- Gradient Function --------
def compute_gradient(x, y, w, b): 
    m = x.shape[0]    
    dj_dw = 0
    dj_db = 0
    for i in range(m):  
        f_wb = w * x[i] + b 
        dj_dw += (f_wb - y[i]) * x[i]
        dj_db += (f_wb - y[i])
    return dj_dw / m, dj_db / m

# -------- Gradient Descent --------
def gradient_descent(x, y, w_in, b_in, alpha, num_iters, cost_function, gradient_function):
    J_history = []
    p_history = []
    w = w_in
    b = b_in

    for i in range(num_iters):
        dj_dw, dj_db = gradient_function(x, y, w , b)
        w = w - alpha * dj_dw
        b = b - alpha * dj_db

        if i < 10000:
            J_history.append(cost_function(x, y, w , b))
            p_history.append((w, b))
        
        if i % math.ceil(num_iters / 10) == 0:
            print(f"Iter {i:4}: Cost={J_history[-1]:.2e}, dj_dw={dj_dw:.2f}, dj_db={dj_db:.2f}, w={w:.2f}, b={b:.2f}")
    
    return w, b, J_history, p_history

# -------- Run Gradient Descent --------
w_init = 0
b_init = 0
iterations = 10000
alpha = 0.01

w_final, b_final, J_hist, p_hist = gradient_descent(x_train, y_train, w_init, b_init, alpha, iterations, compute_cost, compute_gradient)

print(f"\nFinal parameters: w = {w_final:.4f}, b = {b_final:.4f}")

# -------- Cost Plot --------
plt.plot(J_hist)
plt.xlabel("Iteration")
plt.ylabel("Cost")
plt.title("Cost vs. Iterations")
plt.grid(True)
plt.show()

# -------- Predictions --------
def predict(x):
    return w_final * x + b_final

print("\nPredictions:")
print(f"1000 sqft → ${predict(1):.2f}K")
print(f"1200 sqft → ${predict(1.2):.2f}K")
print(f"2000 sqft → ${predict(2):.2f}K")

# -------- Optional: Visualize Fit Line --------
x_vals = np.linspace(0.5, 2.5, 100)
y_vals = predict(x_vals)

plt.scatter(x_train, y_train, color='red', label="Training Data")
plt.plot(x_vals, y_vals, label="Prediction Line")
plt.xlabel("Size (1000 sqft)")
plt.ylabel("Price (1000s of $)")
plt.title("House Price Prediction")
plt.legend()
plt.grid(True)
plt.show()
