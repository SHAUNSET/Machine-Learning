import numpy as np
import matplotlib.pyplot as plt

# Step 1: Training data
x = np.array([1, 2, 3, 4, 5])   # Inputs
y = np.array([2, 4, 6, 8, 10])  # Outputs

# Step 2: Initialize parameters
w = 0  # initial slope
b = 0  # initial intercept

# Step 3: Settings for learning
learning_rate = 0.01
epochs = 1000  # how many times to train
 
# Step 4: Training using gradient descent
n = len(x)  # number of data points

for i in range(epochs):
    y_pred = w * x + b  # Predict using current w and b
    cost = np.sum((y - y_pred)**2) / n  # Mean Squared Error

    # Calculate gradients (how much to adjust w and b)
    dw = -2 * np.sum(x * (y - y_pred)) / n
    db = -2 * np.sum(y - y_pred) / n

    # Update w and b using gradients
    w = w - learning_rate * dw
    b = b - learning_rate * db

    # Show progress every 100 steps
    if i % 100 == 0:
        print(f"Epoch {i}: Cost = {cost:.4f}, w = {w:.4f}, b = {b:.4f}")

# Step 5: Final graph
plt.scatter(x, y, color='blue', label='Original Data')
plt.plot(x, w * x + b, color='red', label='Prediction Line')
plt.xlabel('X (Input)')
plt.ylabel('Y (Output)')
plt.title('Linear Regression')
plt.legend()
plt.grid(True)
plt.show()

# Final learned values
print(f"Final w = {w:.2f}, Final b = {b:.2f}")